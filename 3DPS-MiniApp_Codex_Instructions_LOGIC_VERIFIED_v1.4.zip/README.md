# 3DPS-MiniApp — Codex Project Instruction Package

**Instruction files only; not an application or completed codebase.** The package captures agreed business decisions and guides Codex across the full project.

## Quick start — Codex website (recommended)
1. Create or open a **private GitHub repository** named `3DPS-MiniApp`.
2. Extract the v1.4 archive directly into your repository root. It contains `AGENTS.md`, `docs/` and `prompts/` at the ZIP root (no extra outer folder). Confirm `AGENTS.md` is at the **repository root**; Codex may miss the instructions if they are nested.
3. If source code or documentation already exists, compare/merge files rather than overwriting them. Never upload `.env`, bot tokens, customer model files or payment data to GitHub.
4. In the [Codex website](https://chatgpt.com/codex), prepare/publish a cloud environment connected to this repository. Configure test dependencies and network access as needed; **do not assume a Docker daemon or a public HTTPS preview is available**. Prefer fake credentials and disposable test services.
5. Start a cloud task: **"Read root AGENTS.md and prompts/M00_REPOSITORY_AUDIT.md. Perform M00 only; report findings and stop."** Review the changes and tests, then commit/merge through the repository workflow as appropriate before starting M01.

Codex Cloud tasks have isolated workspaces: work in a task is **not automatically the baseline for a newly started task**. Review and save the changes to the connected repository before opening the next task. Codex Cloud is a development tool, **not** the always-on hosting for your Telegram bot or customer Mini App.

### Optional CachyOS local development
If you also clone the repository locally, the same files work with Git and Docker Compose. Codex CLI is **not required** for the chosen Codex website workflow. See `docs/DEVOPS.md` for optional local setup.

## Package files
- `AGENTS.md` — always-on agent instructions
- `docs/PRODUCT_SPEC.md` — product scope, roles, MVP / non-goals
- `docs/BUSINESS_RULES.md` — business workflows and safety gates
- `docs/STATE_MACHINES.md` — permitted entity transitions, stage-specific guards and refund/hold paths
- `docs/INTEGRITY_RULES.md` — DB constraints, payment credit uniqueness, stock/capacity and delivery invariants
- `docs/DEPENDENCY_MATRIX.md` — milestone contracts, upstream dependencies, release blockers
- `docs/ARCHITECTURE.md` — target technical design and modules
- `docs/DATA_MODEL.md` — logical relational database specification
- `docs/API_CONTRACTS.md` — backend API plan
- `docs/FRONTEND_SPEC.md` — React Mini App UX, routes, reusable components
- `docs/SECURITY.md` — concrete security and threat-model checklist
- `docs/DEVOPS.md` — Codex Cloud, optional CachyOS development, and deployment rules
- `docs/PAYMENTS_COMPLIANCE.md` — physical-print vs digital-design payment requirements and release gate
- `AUDIT_REPORT.md` — initial v1.1 package review history
- `AUDIT_REPORT_V1_2.md` — earlier pre-development audit and corrections
- `AUDIT_REPORT_V1_3.md` — previous review history
- `AUDIT_REPORT_V1_4.md` — final cross-domain logic, DB relationship and milestone dependency review
- `docs/OPEN_DECISIONS.md` — open questions that block *specific live releases*, not development
- `docs/MASTER_ROADMAP.md` — 17 milestones and staged release gates
- `prompts/M00_REPOSITORY_AUDIT.md` — first task to run
- `prompts/TASK_TEMPLATE.md` — reusable task prompt
- `prompts/M01_MINIAPP_FOUNDATION.md` — next task after approved M00
- `prompts/M02_TELEGRAM_AUTH.md` — authentication integration task
- `prompts/M03_*.md` through `prompts/M16_*.md` — one scoped prompt for each later milestone

## Critical restrictions
This is **reviewed documentation**, not a tested product. For first development use, prefer this v1.4 package; Codex must perform M00 on the actual GitHub repository. Manual binding quotes and automatic binding quotes are *both* disabled until explicit live gate approval.

No hardware has been purchased yet. Live customer payment, real production and **all binding quotes (manual or automated)** must stay **off** until appropriate calibration and explicit launch authorization. Two roles only: customer and owner.

## Docs precedence
Business decisions in `AGENTS.md` and `docs/BUSINESS_RULES.md` plus `docs/STATE_MACHINES.md`, `docs/INTEGRITY_RULES.md`, and `docs/DEPENDENCY_MATRIX.md` are the present baseline; a newer owner-approved decision can supersede them, but Codex must record that change in documentation and an architecture decision record. `MASTER_ROADMAP.md` defines milestone order, not permission to skip safety gates.

## Suggested first task on Codex website
"Read AGENTS.md, docs/MASTER_ROADMAP.md and prompts/M00_REPOSITORY_AUDIT.md. Execute only M00: audit the existing repository and propose the minimal foundation plan. Do not implement unrelated milestones."

## Naming / Codex Cloud

Project display name: **3DPS-MiniApp**. Recommended private GitHub repository name: `3DPS-MiniApp`.

If your GitHub repository still uses the former project name, rename it via **GitHub → repository Settings → General → Repository name**; then check or reconnect the selected repository/environment on the Codex website. Renaming the repository does not automatically rename existing branding inside application source code. Ask Codex to audit and update those references separately, without altering IDs, migration histories, secrets, or published URLs automatically.

For Codex Cloud: place `AGENTS.md` at repository root and keep `docs/` and `prompts/` alongside it. Ask Codex to read those files before starting M00.
