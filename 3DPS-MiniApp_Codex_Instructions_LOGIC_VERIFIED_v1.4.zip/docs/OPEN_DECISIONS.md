# Open decisions and release blockers — do not guess

**Status:** maintained during M00 and updated after every approved decision. Open items below do **not** block scaffolding or simulated tests. They **do** block the specific live features indicated.

| Decision | Safe current assumption | Required before | Owner approval / evidence |
|---|---|---|---|
| Physical printer models, quantity, nozzle/build volumes | Virtual profiles only; no real allocation | M16 live print | Hardware list and calibration tests |
| Calibrated slicer/material/quality profiles | Test-only estimates and simulation offers | Binding print quotes, auto quotes | Profile checksums, repeatability/calibration evidence |
| Filament brands, stock, wastage and actual unit costs | Mock stock fixtures, no real commitments | Binding print quote + production | Spool purchase costs and inventory reconciliation |
| Level-2 auto-quote thresholds | Example numbers in `PRODUCT_SPEC` are not defaults | `AUTO_QUOTE_ENABLED=true` | Explicit limits for count, duration, amount, tolerances, inventory and lead time |
| Actual pricing and rounding policy | Versioned test policy | Any binding quote | Owner-approved margin, labor, overhead, taxes, delivery and rounding |
| Digital design deliverable and payment path | Digital in-Telegram service treated as Stars-required; test checkout only | Live digital design checkout | Confirm classification/provider integration and refund policy under current Telegram rules |
| Combined design+print payment classification | Keep separate design/print stages, disabled live combined checkout | Live combined offering | Explicit category/currency decision, with legal/provider review if needed |
| Physical-goods accepted payment methods | No live checkout; test evidence only | Live physical checkout | Supported payment method, verified settlement process and proof of permission |
| Owner Telegram ID and bot username | No real IDs/tokens in docs or repository | Real Telegram login testing | Secure out-of-band provisioned ID and test bot credentials |
| File limits and retention/privacy policy | Conservative quotas and private test-only files | Public customer uploads | Limits by format, retention, deletion and customer communications |
| Delivery areas, fees, SLA, failed-print/reprint/refund terms | No customer guarantees in test UI | Live ordering | Published terms and owner acceptance |
| Security recovery and backup targets | Disposable test data only | Production hosting | RPO/RTO, backup restoration evidence and incident plan |
| Capacity scheduling/overbooking policy | Conservative mock capacity-hold adapter | Any live physical checkout | Machine availability, blackout windows, reservation expiry and conflicts tested |
| Design delivery acceptance and usage rights | Private, test-only versions and scoped revision policy | Live design quote/delivery | Owner-approved scope, file formats, revision count, IP/licensing, and whether combined design+print includes transferable digital CAD/STL files |
| Provider/bank transaction uniqueness scope | Disposable mock transaction keys | Any live owner payment verification | Define provider/account/reference uniqueness rules and process to resolve ambiguous duplicates |

Rules:
1. Document the selected value, date, rationale, approver and affected milestones in a short ADR; update corresponding docs and tests in the same PR.
2. Never silently assume a legal/Telegram provider classification or enable live flags because a payment test succeeds.
3. Decisions can remain pending while implementing unrelated work. The related release gate stays closed.
